var mes:string = "Hello Guys..!!"
console.log(mes);
