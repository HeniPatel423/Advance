// Number.
// String.
// Boolean.
// Void.
// null.
// Undefined.
// Nan.

class FirstCLS { 
    demoFun():void { 
       
       var write="Hello Guys..!!\nhow are you";
       console.log(write); 
    } 
 } 
 var obj = new FirstCLS(); 
 obj.demoFun();