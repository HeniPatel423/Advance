// Number.
// String.
// Boolean.
// Void.
// null.
// Undefined.
// Nan.
var FirstCLS = /** @class */ (function () {
    function FirstCLS() {
    }
    FirstCLS.prototype.demoFun = function () {
        var write = "Hello Guys..!!\nhow are you";
        console.log(write);
    };
    return FirstCLS;
}());
var obj = new FirstCLS();
obj.demoFun();
